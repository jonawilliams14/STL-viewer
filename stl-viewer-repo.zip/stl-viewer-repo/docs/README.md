# docs

This directory holds project documentation assets such as screenshots.

To add a screenshot for the README:
1. Open `index.html` and load a model
2. Take a screenshot
3. Save it here as `screenshot.png`
